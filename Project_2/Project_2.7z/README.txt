HOW TO RUN THE 15 PUZZLE CHALLENGE python file: Project 1

a) Download python scricpt into a given path/folder
b) Make sure all of the sourced python files are downloaded into the same folder
    ie, actionSet.pyand Ques_1.py
c) Finally, run BFS_point.py in a python interpretor
d) Follow User interactive instructions to test any of the Test Cases numbered 1-2
   also shown with their respective coordinates
    - enter the test case number or the option to enter start nodes yourelf; 
      any number outside environment is out of bound or inside the obstacle space is
      not allowed, and will redirect you to the same selection prompt
    - Then enter the desired location (goal node) of the point robot; the same out of
      bounds or inside obstacle space restrictions and response apply
    - BFS search will begin and print confirmation statement at the end
    - Confirm results are correct and press any key to begin animation
    - After animation ends, press any key to terminate display window
    - You can either continue to test the other test cases by pressing 1 for Yes or 
      terminate the program by pressing 0 for No 
    - If you press any other number or string code will terminate 
    - Repeat process for as long as you'd like by following steps from part d above
e) Close python interpreter when done.
